import os

limit = 9
US = 'admin'
MI='hint: \u8fd9\u7f51\u7ad9\u4e0d\u4ec5\u53ef\u4ee5\u4ee5\u8585\u7f8a\u6bdb\uff0c\u6211\u8fd8\u7559\u4e86\u4e2a\u540e\u95e8\uff0c\u5c31\u85cf\u5728\u006c\u0076\u0036\u91cc'
PW = 'SJ%H0c7_3'
debug = False

connect_str = 'sqlite:///%s' % os.path.join(os.getcwd(), 'sshop.db3')
cookie_secret = 'JDIOtOQQjLXklJT/N4aJE.tmYZ.IoK9M0_IHZW448b6exe7p1pysO'
jwt_secret = '1Kun'
Discount = 0.8
Discount_money=10000